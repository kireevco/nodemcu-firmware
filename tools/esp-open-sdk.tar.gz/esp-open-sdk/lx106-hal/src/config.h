/* src/config.h.  Generated from config.h.in by configure.  */
/* src/config.h.in.  Generated from configure.ac by autoheader.  */

/* Name of package */
#define PACKAGE "lx106-hal"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "lx106-hal"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "lx106-hal rc-2010.1"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "lx106-hal"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "rc-2010.1"

/* Version number of package */
#define VERSION "rc-2010.1"
