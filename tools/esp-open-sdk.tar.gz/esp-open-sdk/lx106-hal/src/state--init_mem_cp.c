#define __SPLIT__init_mem_cp
#include "state.c"
