#define __SPLIT__vpri
#include "interrupts.c"
