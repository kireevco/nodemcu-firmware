#define __SPLIT__vpri_to_intlevel
#include "interrupts.c"
