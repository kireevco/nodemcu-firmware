#define __SPLIT__timer_interrupt
#include "interrupts.c"
