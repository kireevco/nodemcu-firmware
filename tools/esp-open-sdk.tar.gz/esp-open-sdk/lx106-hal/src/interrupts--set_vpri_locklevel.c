#define __SPLIT__set_vpri_locklevel
#include "interrupts.c"
