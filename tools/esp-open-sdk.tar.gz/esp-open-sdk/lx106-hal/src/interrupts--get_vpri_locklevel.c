#define __SPLIT__get_vpri_locklevel
#include "interrupts.c"
