#define __SPLIT__init_mem_extra
#include "state.c"
