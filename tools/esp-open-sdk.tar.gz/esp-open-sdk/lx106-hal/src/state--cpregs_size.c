#define __SPLIT__cpregs_size
#include "state.c"
