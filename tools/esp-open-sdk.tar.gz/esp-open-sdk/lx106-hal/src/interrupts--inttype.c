#define __SPLIT__inttype
#include "interrupts.c"
