#define __SPLIT__vpri_int_disable
#include "interrupts.c"
